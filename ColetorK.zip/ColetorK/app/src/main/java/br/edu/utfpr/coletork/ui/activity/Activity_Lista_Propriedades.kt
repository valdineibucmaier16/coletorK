package br.edu.utfpr.coletork.ui.activity

import android.content.Intent
import android.os.Bundle

import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.edu.utfpr.coletork.R
import br.edu.utfpr.coletork.asynctask.BaseAsyncTask
import br.edu.utfpr.coletork.database.AppDatabase
import br.edu.utfpr.coletork.database.dao.PropriedadeDao
import br.edu.utfpr.coletork.model.Propriedade
import br.edu.utfpr.coletork.ui.adapter.recyclerview.ListaPropriedadesAdapter
import br.edu.utfpr.coletork.ui.dialog.AdicionaPropriedadeDialog
import kotlinx.android.synthetic.main.activity_lista_propriedades.*
import kotlinx.android.synthetic.main.propriedade_item.*
import kotlin.math.absoluteValue

private const val TITULO_APPBAR = "Propriedades"
class Activity_Lista_Propriedades : AppCompatActivity() {


    private lateinit var dao: PropriedadeDao

    private val viewDaActivity by lazy {
        window.decorView
    }
    private val viewGroupDaActivity by lazy {
        viewDaActivity as ViewGroup
    }

    private val adapter by lazy {
        ListaPropriedadesAdapter(context = this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_propriedades)
        title = TITULO_APPBAR
        configuraRecyclerView();
        configuraFabAdicionaPropriedade();

        val db : AppDatabase = AppDatabase.getInstance(this)
        dao = db.propriedadeDao;

        buscaPropriedades();
    }

    override fun onResume() {
        super.onResume()
    }

    private fun buscaPropriedades() {
        BaseAsyncTask(quandoExecuta = {
            dao.buscaTodos()
        }, quandoFinaliza = {resultado -> adapter.atualiza(resultado) }).execute()


    }

    private fun configuraFabAdicionaPropriedade() {
        activity_lista_produtos_fab_adiciona_propriedade.setOnClickListener { chamaDialogDeAdicao() }
    }

    private fun chamaDialogDeAdicao() {
        AdicionaPropriedadeDialog(viewGroupDaActivity, this)
                .chama { propriedadeCriada ->
                    adiciona(propriedadeCriada)

                }
    }


    private fun adiciona(propriedade: Propriedade) {
        BaseAsyncTask(
                quandoExecuta = {
                    dao.salva(propriedade)

                }, quandoFinaliza = {
            adapter.adiciona(propriedade)

                }
        ).execute()

    }


    private fun configuraRecyclerView() {


        //val divisor = DividerItemDecoration(this, LinearLayoutManager.VERTICAL)
        //activity_lista_propriedades_recyclerview.addItemDecoration(divisor)
        activity_lista_propriedades_recyclerview.adapter = adapter
        adapter.quandoItemClicado= this::abreVisualizadorPropriedade

        //adapter.quandoItemClicado = this::abreVisualizadorNoticia
    }

    private fun abreVisualizadorPropriedade(it: Propriedade) {
        val intent = Intent(this, Activity_Visualiza_Propriedade::class.java)
        intent.putExtra("propriedadeId", it.id)
        startActivity(intent)

    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
            val idDoMenu = item?.itemId
            if(idDoMenu == 1){


//                var propriedadeSelecionada = adapter.getItemPropriedade(adapter.posicaoPropriedadeSelecionada)
//               //
//                Toast.makeText(this, propriedadeSelecionada.nome, Toast.LENGTH_LONG).show()
//
////                val propriedadeSelecionada = adapter.getItemPropriedade(posicaoPropriedade)
//                remove(propriedadeSelecionada, adapter.posicaoPropriedadeSelecionada )




                return true
            }
            return super.onContextItemSelected(item)
        }


//    private fun remove(posicaoDaTransacao: Int, propriedadeRemovida: Propriedade) {
//        BaseAsyncTask(quandoExecuta = {dao.remove(propriedadeRemovida)},
//                quandoFinaliza = {resultado-> adapter.remove(posicaoDaTransacao,adapter.buscaPropriedadePorPosicao(posicaoDaTransacao))}).execute()
//
//    }

    private fun remove(propriedade: Propriedade, posicao:Int) {
        BaseAsyncTask(
                quandoExecuta = {
                    dao.remove(propriedade)
                }, quandoFinaliza = {
            adapter.remove(posicao, propriedade)
        }
        ).execute()



    }




}