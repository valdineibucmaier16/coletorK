package br.edu.utfpr.coletork.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Propriedade(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val nome: String = "",
    val proprietario: String = "",
    val telefone: String = "",
    val estado: String = "",
    val cidade: String = ""
){

}
