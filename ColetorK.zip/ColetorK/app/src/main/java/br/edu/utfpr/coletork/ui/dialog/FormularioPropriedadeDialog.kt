package br.edu.utfpr.coletork.ui.dialog

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import br.edu.utfpr.coletork.R
import br.edu.utfpr.coletork.model.Propriedade
import kotlinx.android.synthetic.main.formulario_propriedade.view.*

abstract class FormularioPropriedadeDialog(private val context: Context,
                                           private val viewGroup: ViewGroup) {

    private val viewCriada = criaLayout()
    protected val campoNome = viewCriada.formulario_propriedade_campo_nome
    protected val campoProprietario = viewCriada.formulario_propriedade_campo_proprietario
    protected val campoTelefone = viewCriada.formulario_propriedade_campo_telefone
    protected val campoEstado = viewCriada.formulario_propriedade_campo_estado
    protected val campoCidade = viewCriada.formulario_propriedade_campo_cidade
    abstract protected val tituloBotaoPositivo: String
    abstract protected val tituloDialog: String

    private fun criaLayout(): View {
        return LayoutInflater.from(context)
                .inflate(R.layout.formulario_propriedade, viewGroup, false)
    }

    fun chama(delegate: (propriedade: Propriedade) -> Unit){
        configuraFormulario(delegate)
    }

    private fun configuraFormulario(delegate: (propriedade: Propriedade) -> Unit) {
        AlertDialog.Builder(context)
                .setView(viewCriada)
                .setTitle(tituloDialog)
                .setPositiveButton(tituloBotaoPositivo,
                        { _, _ ->
                            val campoNome= campoNome.text.toString()
                            val campoProprietario = campoProprietario.text.toString()
                            val campoTelefone = campoTelefone.text.toString()
                            val campoEstado = campoEstado.text.toString()
                            val campoCidade = campoCidade.text.toString()

                            val propriedadeCriada = Propriedade(nome = campoNome,
                                    proprietario = campoProprietario,
                                    telefone = campoTelefone,
                                    estado = campoEstado,
                                    cidade = campoCidade)

                            delegate(propriedadeCriada)
                        })
                .setNegativeButton("Cancelar", null)
                .show()
    }
}