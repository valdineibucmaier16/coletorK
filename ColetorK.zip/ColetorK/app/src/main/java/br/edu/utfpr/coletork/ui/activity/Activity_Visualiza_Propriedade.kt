package br.edu.utfpr.coletork.ui.activity

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.edu.utfpr.coletork.R
import br.edu.utfpr.coletork.asynctask.BaseAsyncTask
import br.edu.utfpr.coletork.database.AppDatabase
import br.edu.utfpr.coletork.database.dao.PropriedadeDao
import br.edu.utfpr.coletork.model.Propriedade
import kotlinx.android.synthetic.main.activity_visualiza_propriedade.*

private const val TITULO_APPBAR = "Propriedade"
class Activity_Visualiza_Propriedade : AppCompatActivity() {

    private val propriedadeId: Long by lazy {
        intent.getLongExtra("propriedadeId", 0)

    }

    private lateinit var dao: PropriedadeDao

    private lateinit var propriedade: Propriedade

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_visualiza_propriedade)
        title = TITULO_APPBAR
        val db: AppDatabase = AppDatabase.getInstance(this)
        dao = db.propriedadeDao;

        Toast.makeText(this, propriedadeId.toString(), Toast.LENGTH_LONG).show() // coloquei aqui
    }

    override fun onResume() {
        super.onResume()
        buscaPropriedadeSelecionada()
    }

    private fun buscaPropriedadeSelecionada() {


        BaseAsyncTask(quandoExecuta = {
            dao.buscaPorId(propriedadeId)
        }, quandoFinaliza = { propriedadeEncontrada ->
            propriedadeEncontrada?.let {
                this.propriedade = it
                preencheCampos(it)

            }
        }).execute()


    }

    private fun preencheCampos(it: Propriedade) {
        activity_visualiza_propriedade_nome.text = propriedade.nome
        activity_visualiza_propriedade_proprietario.text = propriedade.proprietario
        activity_visualiza_propriedade_telefone.text = propriedade.telefone
        activity_visualiza_propriedade_estado.text = propriedade.estado
        activity_visualiza_propriedade_cidade.text = propriedade.cidade
    }
}