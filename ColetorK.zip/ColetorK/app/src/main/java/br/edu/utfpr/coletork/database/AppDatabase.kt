package br.edu.utfpr.coletork.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import br.edu.utfpr.coletork.database.dao.PropriedadeDao
import br.edu.utfpr.coletork.model.Propriedade


private const val NOME_BANCO_DE_DADOS = "coletor.db"

@Database(entities = [Propriedade::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract val propriedadeDao: PropriedadeDao

    companion object {
        private lateinit var db :AppDatabase

        fun getInstance(context: Context): AppDatabase {

            if(::db.isInitialized) return db

            db = return Room.databaseBuilder(
                context,
                AppDatabase::class.java,
                NOME_BANCO_DE_DADOS
            ).build()

            return db
        }

    }
}